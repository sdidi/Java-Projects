package com.SabreTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.swing.JOptionPane;

import org.junit.Test;
import org.junit.runner.RunWith;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "sabre.xml"})
public class DIExamples {
	@Autowired
	MessageAlerts service;
	
	@Test
	public void mainTest() {
		JOptionPane.showMessageDialog(null,service.alertMessage());
	}
}
