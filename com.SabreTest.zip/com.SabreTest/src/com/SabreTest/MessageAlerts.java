package com.SabreTest;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class MessageAlerts {
	@Bean
	public String alertMessage() {
		return "Time to go ";
	}
}
